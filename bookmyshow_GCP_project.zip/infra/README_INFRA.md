Infra artifacts
- cloudrun_notification.tf: example Terraform
- upload_static.sh: uploads static assets to GCS
- pgbouncer.ini: sample PgBouncer config
