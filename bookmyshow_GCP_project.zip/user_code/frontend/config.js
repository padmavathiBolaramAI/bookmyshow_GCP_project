// Runtime config for frontend
window.__ENV__ = { API_HOST: 'http://localhost:3000' };
